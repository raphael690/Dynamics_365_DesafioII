﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace PluginProjetoDesafioII
{
    public class PluginMyWorkflow : CodeActivity
    {
        [RequiredArgument]
        [Input("String input")]
        public InArgument<string> cpfInput { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            string cpf = cpfInput.Get(context);

            if (cpf.Length != 11 ||
            cpf == "00000000000" ||
            cpf == "11111111111" ||
            cpf == "22222222222" ||
            cpf == "33333333333" ||
            cpf == "44444444444" ||
            cpf == "55555555555" ||
            cpf == "66666666666" ||
            cpf == "77777777777" ||
            cpf == "88888888888" ||
            cpf == "99999999999")
            {
                throw new InvalidPluginExecutionException("Campo CPF inválido!");
            }
        }
    }
}
