﻿using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PluginProjetoDesafioII
{
    public class PluginAccountPreOperation : IPlugin
    {
        // Método requerido para execução do plugin recebendo como parâmetro os dados do provedor de serviços
        public void Execute(IServiceProvider serviceProvider)
        {
            // Variavel contendo o contexto da execução
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            //Variavel contendo o service Factory da Organização
            IOrganizationServiceFactory serviceFactory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

            //Variavel contendo o Service Admin que estabelece os serviços de conexão com o Dataverse
            IOrganizationService serviceAdmin = serviceFactory.CreateOrganizationService(null);

            //Variavel do Trace que armazena informações de LOG
            ITracingService trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            //Verifica se contém dados para o destino e se corresponde a uma Entity
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                // Variável do tipo Entity herdando a entidade do contexto
                Entity entidadeContexto = (Entity)context.InputParameters["Target"];

                if (entidadeContexto.LogicalName == "account") // verifica se a entidade do contexto é !
                {
                    if (entidadeContexto.Attributes.Contains("address1_telephone1")) // verifica se contém o atributo telephone1
                    {
                        // variável para herdar o conteúdo do atributo telephone1 do contexto
                        var phone1 = entidadeContexto["address1_telephone1"].ToString();

                        // variável string contendo FechXML para consulta do contato
                        string FetchContact = //@"<?xml version='1.0'?>" +
                            "<fetch version = '1.0' output - format = 'xml-platform' mapping = 'logical' distinct = 'false'>" +
                            "<entity name = 'contacto'>" +
                            "<attribute name = 'yomifullname'/>" +
                            "<attribute name = 'emailaddress1'/>" +
                            "<attribute name = 'parentcustomerid'/>" +
                            "<attribute name = 'address1_telephone1' />" +
                            "<attribute name = 'statecode'/>" +
                            "<attribute name = 'contactid' />" +
                            //"<order attribute = 'fullname' descending = 'false' />" +
                            "<filter type = 'and' >" +
                            "<condition attribute = 'address1_telephone1' operator = 'eq' value='" + phone1 + "' />" +
                            "</filter >" +
                            "</entity >" +
                            "</fetch >";                        

                        trace.Trace("FetchContact: " + FetchContact); // armazena informações de LOG

                        // Variável contendo o retorno da consulta FetchXML
                        var primarycontact = serviceAdmin.RetrieveMultiple(new FetchExpression(FetchContact));

                        if (primarycontact.Entities.Count > 0) // verifica se contém entidade
                        {
                            // para cada entidade retornada atribui a variável entityContact
                            foreach (var entityContact in primarycontact.Entities)
                            {
                                // atribui referência de entidade para o atributo primarycontactid (contato primário)
                                entidadeContexto["primarycontactid"] = new EntityReference("contact", entityContact.Id);
                            }
                        }

                    }
                }
            }
        }
    }
}
