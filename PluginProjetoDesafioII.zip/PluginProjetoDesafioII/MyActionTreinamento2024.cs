﻿using System;
using Microsoft.Xrm.Sdk;
using System.Threading.Tasks;

namespace PluginProjetoDesafioII
{
    public class MyActionTreinamento2024 : IPlugin
    {
        // Método requerido para execução do plugin recebendo como parâmetro os dados do provedor de serviços
        public void Execute(IServiceProvider serviceProvider)
        {
            // Variavel contendo o contexto da execução
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            //Variavel cotendo o service Factory da Organização
            IOrganizationServiceFactory serviceFactory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

            //Variavel contendo o Service Admin que estabelece os serviços de conexão com o Dataverse
            IOrganizationService serviceAdmin = serviceFactory.CreateOrganizationService(null);

            //Variavel do Trace que armazena informações de LOG
            ITracingService trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            trace.Trace ("Minha Action sendo executada com sucesso!");

            //Criar Novo registro de Aluno
            Entity alunos = new Entity("dio_alunos");
            alunos["dio_name"] = "Novo Aluno via Action Helena Maria Stefany da Paz - " + DateTime.Now.ToString();
            alunos["dio_cpf"] = "44106763850";
            Guid AlunosId = serviceAdmin.Create(alunos);


        }
    }
}
