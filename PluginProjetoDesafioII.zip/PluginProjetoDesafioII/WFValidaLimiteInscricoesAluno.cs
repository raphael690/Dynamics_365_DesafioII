﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using System.Threading;
using System.Net.NetworkInformation;

namespace PluginProjetoDesafioII
{
    public class WFValidaLimiteInscricoesAluno : CodeActivity
    {
        #region Parametros
        // Recebe o usuário do contexto
        [Input("Usuario")]
        [ReferenceTarget("systemuser")]
        public InArgument<EntityReference> usuarioEntrada { get; set; }

        // Recebe o contexto
        [Input("AlunoxCursos")]
        [ReferenceTarget("dio_alunoxcursos")]
        public InArgument<EntityReference> RegistroContexto { get; set; }

        [Output("Saida")]
        public OutArgument<string> saida { get; set; }
        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            // Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService trace = executionContext.GetExtension<ITracingService>();

            // informação para o log de rastreamento de Plugin
            trace.Trace("dio_alunoxcursos: " + context.PrimaryEntityId);

            //declaro variável com o guid da entidade primaria em uso
            Guid guidAlunoXCursos = context.PrimaryEntityId;

            // Informação para o log de Rastreamento de Plugin!
            trace.Trace("guidAlunoXCursos: " + guidAlunoXCursos);

            String fetchAlunoxCursos = "<fecth distinct='false' mapping = 'logical' output-format = 'xml-platform' version = '1.0'>";
            fetchAlunoxCursos += "<entity name = 'dio_alunoxcursos' >";
            fetchAlunoxCursos += "<attribute name = 'dio_alunoxcursosid' />";

            fetchAlunoxCursos += "<attribute name = 'dio_name' />";
            fetchAlunoxCursos += "<attribute name = 'dio_emcurso' />";
            fetchAlunoxCursos += "<attribute name = 'createdon' />";
            fetchAlunoxCursos += "<attribute name = 'dio_alunos' />";
            fetchAlunoxCursos += "<order descending = 'false' attribute = 'dio_name' />";

            fetchAlunoxCursos += "<filter type = 'and' >";
            fetchAlunoxCursos += "<condition attribute = 'dio_alunoxcursosid' value = '" + guidAlunoXCursos + "' uitype = 'dio_alunoxcursos' operator = 'eq' />";
            fetchAlunoxCursos += "</filter> ";
            fetchAlunoxCursos += "</entity> ";
            fetchAlunoxCursos += "</fetch> ";
            trace.Trace("fetchAlunoxCursos: " + fetchAlunoxCursos);

            var entityAlunoxCursos = service.RetrieveMultiple(new FetchExpression(fetchAlunoxCursos));
            trace.Trace("entityAlunoxCursos: " + entityAlunoxCursos.Entities.Count);

            Guid guidalunos = Guid.Empty;
            foreach (var item in entityAlunoxCursos.Entities)
            {
                string nomeCurso = item.Attributes["dio_name"].ToString();
                trace.Trace("nomeCurso: " + nomeCurso);

                var entityalunos = ((EntityReference)item.Attributes["dio_alunos"]).Id;
                guidalunos = ((EntityReference)item.Attributes["dio_alunos"]).Id;
                trace.Trace("entityalunos: " + entityalunos);
            }
            String fetchAlunoxCursosQtde = "<fetch distinct = 'false' mapping = 'logical' output-format = 'xml-platform' version = '1.0' >";
            fetchAlunoxCursosQtde += "<entity name = 'dio_alunoxcursos>";
            fetchAlunoxCursosQtde += "<attribute name = 'dio_alunoxcursosid' />";

            fetchAlunoxCursosQtde += "<attribute name = 'dio_name' />";
            fetchAlunoxCursosQtde += "<attribute name = 'dio_emcurso' />";
            fetchAlunoxCursosQtde += "<attribute name = 'createdon' />";
            fetchAlunoxCursosQtde += "<attribute name = 'dio_alunos' />";
            fetchAlunoxCursosQtde += "<order descebding = 'false' attribute = 'dio_name' />";

            fetchAlunoxCursosQtde += "<filter type = 'and' >";
            fetchAlunoxCursosQtde += "<condition attribute = 'dio_aluno' value = '" + guidalunos + "' operator = 'eq' />";
            fetchAlunoxCursosQtde += "</filter>";
            fetchAlunoxCursosQtde += "</entity>";
            fetchAlunoxCursosQtde += "</fetch>";
            trace.Trace("fetchAlunoxCursosQtde: " + fetchAlunoxCursosQtde);

            var entityAlunoxCursosQtde = service.RetrieveMultiple(new FetchExpression(fetchAlunoxCursosQtde));
            trace.Trace("entityAlunoxCursosQtde: " + entityAlunoxCursosQtde.Entities.Count);
            if (entityAlunoxCursosQtde.Entities.Count > 2)
            {
                saida.Set(executionContext, "Aluno excedeu limite de cursos ativos!");
                trace.Trace("Aluno excedeu limite de cursos ativos!");
                throw new InvalidPluginExecutionException("Aluno excedeu limite de cursos ativos!");
            }
           // throw new NotImplementedException();
        }
    }
}
