﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace PluginProjetoDesafioII
{
    public class PluginAlunoPreValidation : IPlugin
    {
        // Método requerido para execução do plugin recebendo como parâmetro os dados do provedor de serviços
        public void Execute(IServiceProvider serviceProvider)
        {
            // Variavel contendo o contexto da execução
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            //Variavel cotendo o service Factory da Organização
            IOrganizationServiceFactory serviceFactory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

            //Variavel contendo o Service Admin que estabelece os serviços de conexão com o Dataverse
            IOrganizationService serviceAdmin = serviceFactory.CreateOrganizationService(null);

            //Variavel do Trace que armazena informações de LOG
            ITracingService trace = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            //Variavel do tipo Entity vazia
            Entity entidadeContexto = null;

            if (context.InputParameters.Contains("Target")) //Verifica se contém dados para o destino
            {
                entidadeContexto = (Entity)context.InputParameters["Target"];// atribui o contexto da entidade para a variavel

                trace.Trace("Entidade do Contexto: " + entidadeContexto.Attributes.Count); //armazena informações de LOG
                trace.Trace("Entidade do Contexto contém CPF: " + entidadeContexto.Contains("dio_cpf"));

                if (entidadeContexto == null) //Verifica se a entidade do contexto está vazia
                {
                    return;  // caso verdadeira retorna sem nada executar
                }

                if (!entidadeContexto.Contains("dio_cpf")) // Verifica se o atributo CPF não está presente no contexto
                {
                    throw new InvalidPluginExecutionException("Campo CPF é Obrigatório!");  // exibe Exception de Erro
                }
                else
                {
                    if (entidadeContexto.Attributes["dio_cpf"] == null)
                    {
                        throw new Exception("Campo CPF é obrigatório");
                    }
                    trace.Trace("CPF informado: " + entidadeContexto["dio_cpf"]);
                }
            }
        }
    }
}